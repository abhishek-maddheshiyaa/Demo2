package com.cg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Doctor;
import com.cg.service.DoctorService;
import com.cg.service.IDoctorService;


@RequestMapping("/doc")
@RestController
public class DoctorController {
	
	@Autowired
	DoctorService doctorService;
	
	@GetMapping("/hello")
	public String getD()
	{
		return "Hello Doctor";
	}
	
	@GetMapping("/doctors")
	public List<Doctor> getDoctors()
	{
		return doctorService.findAllDoctors();
	}
	
	@GetMapping(path = "/doctors/{id}")
 	public Optional<Doctor> getByDoctorId(@PathVariable int id)
 	{
 		return doctorService.findDoctorById(id);
 	}
	
	@PostMapping("/doctors")
	public Doctor createMyDoctor(@RequestBody Doctor d)
	{
		return doctorService.createDoctor(d);
	}
	
	@DeleteMapping(path = "/products/{id}")
 	public Optional<Doctor> deleteByDoctorId(@PathVariable int id)
 	{
 		return doctorService.deleteDoctor(id);
 	}
	
	@PutMapping(path = "/products")
	public String updateProductById(@RequestBody Doctor d)
	{
		int id= d.getId();
		return doctorService.updateDoctor(d, id);
	}
	
}
