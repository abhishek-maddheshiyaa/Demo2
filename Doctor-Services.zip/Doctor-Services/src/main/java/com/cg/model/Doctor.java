package com.cg.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "DoctorTable")
public class Doctor {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;
	
	@Column(name = "Doctor_Name")
	@NotBlank(message = "Doctor name cannot be empty or null")
	private String doctorName;
	
	@Column(name = "Qualification")
	@NotBlank(message = "Doctor qualification cannot be empty or null")
	private String qualification;

	public Doctor(int id, @NotBlank(message = "Doctor name cannot be empty or null") String doctorName,
			@NotBlank(message = "Doctor qualification cannot be empty or null") String qualification) {
		super();
		this.id = id;
		this.doctorName = doctorName;
		this.qualification = qualification;
	}

	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	
	
	
}
